package main

//import (
//	bmg "buffer_manager"
//	fm "file_manager"
//	"fmt"
//	lm "log_manager"
//	"math/rand"
//	mm "metadata_management"
//	record_mgr "record_manager"
//	"tx"
//)

import (
	"parser"
)

func main() {
	sql := "update Customers set City=\"Frankfurt\" where CustomerID = 1"
	sqlParser := parser.NewSQLParser(sql)
	sqlParser.UpdateCmd()

}
